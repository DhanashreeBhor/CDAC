package com.cdac.assignment;

import java.util.*;

public class Question34 {


		public static void main(String args[]) {
			String password = "password123";
			Scanner sc=new Scanner(System.in);
			//Scanner.close();
			
			do {
				System.out.print("Enter the password: ");
				String pass = sc.next();
				if(pass.equals(password)) {
					System.out.println("Password is correct!");
					break;
				}
				else
					System.out.println("Password is incorrect");
			}while(true);
			sc.close();
		}
	}

