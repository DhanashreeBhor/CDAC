package com.cdac.assignment;

import java.util.*;

public class Circle {
	public static void main(String[] args) {
		float pi = 3.14f;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the radius of circle: ");
		float rad = sc.nextFloat();
		float area = pi * rad * rad;
		System.out.println("Area of cicle is: " +area);
		sc.close();
	} 
}
